// @ts-ignore
// const fetcher = (...args: any) => fetch(...args).then((res) => res.json())

// useEffect(() => {
//   setLoading(true)
//   fetch('/api/profile-data')
//     .then((res) => res.json())
//     .then((data) => {
//       setData(data)
//       setLoading(false)
//     })
// }, [])

// if (isLoading) return <p>Loading...</p>
// if (!data) return <p>No profile data</p>